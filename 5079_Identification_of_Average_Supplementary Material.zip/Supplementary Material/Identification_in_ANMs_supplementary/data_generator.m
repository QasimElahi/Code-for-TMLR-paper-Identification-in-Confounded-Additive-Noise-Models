clc
clear
samples = 300;
warning off
 for nv =3:1:8
  for j =1:1:50

 while(1)     
varm = 3.*eye(nv+1,nv+1)+rand(nv+1,nv+1);

varm = (varm+varm')./2;
if (all(eig(varm)>=0))
    break; 
end
end

 AA = double(triu(rand(nv,nv) <=0.60,1));
dmax =0.60*nv;
S_log = [];
Ad =zeros(nv,nv);
for i =1:30
   S = rand(1,nv);
   S = double((S<=(1-1./dmax)));
   S_log = [S_log ; S];
   S = find(S==1);
    Ad = Ad | Learn_Acnestral_graph(S,nv,AA,varm,samples);
    i
 [nv j i sum(sum((xor(Ad,AA))))]
 Err(nv,j,i) = sum(sum((xor(Ad,AA))));
end

  end
 end

clc



 for nv = 8:2:20
  for j =1:1:50


  while(1)     
varm = 3.*eye(nv+1,nv+1)+rand(nv+1,nv+1);

varm = (varm+varm')./2;
if (all(eig(varm)>=0)) break; end
end

 AA = double(triu(rand(nv,nv) <=0.60,1));
dmax =0.60*nv;
Ad =zeros(nv,nv);
S_log = [];
for i =1:30
   S = rand(1,nv);
   S = double((S<=(1-1./dmax)));
   S_log = [S_log ; S];
   S = find(S==1);
    Ad = Ad | Learn_Acnestral_graph(S,nv,AA,varm,samples);
    i
   Ad = double(Ad);
AA; 
 [nv j i sum(sum((xor(Ad,AA))))]
 Err(nv,j,i) = sum(sum((xor(Ad,AA))));
end
Ad = double(Ad);

  end
 end
save("data_300.mat")


clear

samples = 300;

 for nv =3:1:8
  for j =1:1:50

 while(1)     
varm = 3.*eye(nv+1,nv+1)+rand(nv+1,nv+1);

varm = (varm+varm')./2;
if (all(eig(varm)>=0)) break; end
end


 AA = double(triu(rand(nv,nv) <=1.5*log(nv)/nv,1));
dmax =1.5*log(nv)/nv*nv;
S_log = [];
Ad =zeros(nv,nv);
for i =1:30
   S = rand(1,nv);
   S = double((S<=(1-1./dmax)));
   S_log = [S_log ; S];
   S = find(S==1);
    Ad = Ad | Learn_Acnestral_graph(S,nv,AA,varm,samples);
    i
 [nv j i sum(sum((xor(Ad,AA))))]
 Err(nv,j,i) = sum(sum((xor(Ad,AA))));
end

  end
 end

clc



 for nv = 8:2:20
  for j =1:1:50

 while(1)     
varm = 3.*eye(nv+1,nv+1)+rand(nv+1,nv+1);

varm = (varm+varm')./2;
if (all(eig(varm)>=0))  break; end
end


AA = double(triu(rand(nv,nv) <=1.5*log(nv)/nv,1));
dmax =1.5*log(nv)/nv*nv;
S_log = [];
Ad =zeros(nv,nv);
for i =1:30
   S = rand(1,nv);
   S = double((S<=(1-1./dmax)));
   S_log = [S_log ; S];
   S = find(S==1);
    Ad = Ad | Learn_Acnestral_graph(S,nv,AA,varm,samples);
    i
   Ad = double(Ad);
AA; 
 [nv j i sum(sum((xor(Ad,AA))))]
 Err(nv,j,i) = sum(sum((xor(Ad,AA))));
end
Ad = double(Ad);

  end
 end
save("data_300_lgn.mat")


clear

samples = 300;

 for nv =3:1:8
  for j =1:1:50

 while(1)     
varm = 3.*eye(nv+1,nv+1)+rand(nv+1,nv+1);

varm = (varm+varm')./2;
if (all(eig(varm)>=0)) break; end
end


 AA = double(triu(rand(nv,nv) <=3/nv,1));
dmax =3/nv*nv;
S_log = [];
Ad =zeros(nv,nv);
for i =1:30
   S = rand(1,nv);
   S = double((S<=(1-1./dmax)));
   S_log = [S_log ; S];
   S = find(S==1);
    Ad = Ad | Learn_Acnestral_graph(S,nv,AA,varm,samples);
    i
 [nv j i sum(sum((xor(Ad,AA))))]
 Err(nv,j,i) = sum(sum((xor(Ad,AA))));
end

  end
 end

clc



 for nv = 8:2:20
  for j =1:1:50

 while(1)     
varm = 3.*eye(nv+1,nv+1)+rand(nv+1,nv+1);

varm = (varm+varm')./2;
if (all(eig(varm)>=0)) break; end
end


AA = double(triu(rand(nv,nv) <=3/nv,1));
dmax =3/nv*nv;
S_log = [];
Ad =zeros(nv,nv);
for i =1:30
   S = rand(1,nv);
   S = double((S<=(1-1./dmax)));
   S_log = [S_log ; S];
   S = find(S==1);
    Ad = Ad | Learn_Acnestral_graph(S,nv,AA,varm,samples);
    i
   Ad = double(Ad);
AA; 
 [nv j i sum(sum((xor(Ad,AA))))]
 Err(nv,j,i) = sum(sum((xor(Ad,AA))));
end
Ad = double(Ad);

  end
 end
save("data_300_cnst.mat")

clc
clear

aaa=0;
ind =0;
for xxx = 10:10:100
    ind = ind +1;
 for nv =20:1:20
  for j =1:1:50

varm = 2.0.*eye(nv+1,nv+1)+rand(nv+1,nv+1);

varm = (varm+varm')./2;

 AA = double(triu(rand(nv,nv) <= 0.60,1));
dmax = 0.60*nv;
S_log = [];
Ad =zeros(nv,nv);
for i =1:1:xxx
   S = rand(1,nv);
   S = double((S<=(1-1./dmax)));
   S_log = [S_log ; S];
   S = find(S==1);
 
    i;
end

tmp = S_log';
d=0;
 for ii =1:1:nv
   for jj = 1:1:size(tmp,2)
     tmp2 = AA(:,ii).*tmp(:,jj);
     if (sum(tmp2 == AA(:,ii))==nv && tmp(ii,jj) == 0) d(ii) =1;
         ii;
     [ AA(:,ii) tmp(:,jj)];
    break 
     end
 end
end

aaa = (sum(d)==nv);
e(j,ind) = double(aaa);
  end
 end


aaa=0;
e(:,ind);
xxx
end
save("data_infer_20_n_d.mat")



clc
clear

aaa=0;
ind =0;
for xxx = 10:10:100
    ind = ind +1;
 for nv =20:1:20
  for j =1:1:50

varm = 2.0.*eye(nv+1,nv+1)+rand(nv+1,nv+1);

varm = (varm+varm')./2;

 AA = double(triu(rand(nv,nv) <= 2.0*log(nv)/nv,1));
dmax = 2.0*log(nv)/nv*nv;
S_log = [];
Ad =zeros(nv,nv);
for i =1:1:xxx
   S = rand(1,nv);
   S = double((S<=(1-1./dmax)));
   S_log = [S_log ; S];
   S = find(S==1);
 
    i;
end

tmp = S_log';
d=0;
 for ii =1:1:nv
   for jj = 1:1:size(tmp,2)
     tmp2 = AA(:,ii).*tmp(:,jj);
     if (sum(tmp2 == AA(:,ii))==nv && tmp(ii,jj) == 0) d(ii) =1;
         ii;
     [ AA(:,ii) tmp(:,jj)];
    break 
     end
 end
end

aaa = (sum(d)==nv);
e(j,ind) = double(aaa);
  end
 end


aaa=0;
e(:,ind);
xxx
end
save("data_infer_20_lgn_d.mat")



clc
clear

aaa=0;
ind =0;
for xxx = 10:10:100
    ind = ind +1;
 for nv =20:1:20
  for j =1:1:50

varm = 2.0.*eye(nv+1,nv+1)+rand(nv+1,nv+1);

varm = (varm+varm')./2;

 AA = double(triu(rand(nv,nv) <= 3/nv,1));
dmax = 3/nv*nv;
S_log = [];
Ad =zeros(nv,nv);
for i =1:1:xxx
   S = rand(1,nv);
   S = double((S<=(1-1./dmax)));
   S_log = [S_log ; S];
   S = find(S==1);
 
    i;
end

tmp = S_log';
d=0;
 for ii =1:1:nv
   for jj = 1:1:size(tmp,2)
     tmp2 = AA(:,ii).*tmp(:,jj);
     if (sum(tmp2 == AA(:,ii))==nv && tmp(ii,jj) == 0) d(ii) =1;
         ii;
     [ AA(:,ii) tmp(:,jj)];
    break 
     end
 end
end

aaa = (sum(d)==nv);
e(j,ind) = double(aaa);
  end
 end


aaa=0;
e(:,ind);
xxx
end
save("data_infer_20_cnt_d.mat")

clc
clear
nv=4;
data_samples =[100 300 500 800 1000 2000 3000]
for ind =1:1:size(data_samples,2)
    n =data_samples(ind);
for num =1:1:30
varm = 2.0.*eye(nv+1,nv+1)+rand(nv+1,nv+1);
varm = (varm+varm')./2;

 A = double(triu(rand(nv,nv) >= 0.30,1));
  Ad =A;
  AA =A;

[data Ut] = rand_dag_sample_f(AA,nv,zeros(1,n),varm,zeros(1,n),n);



for i =1:1:n
        val = data(i,:);
 for j =1:1:nv

    intv = Ad(:,j)';

    data1 = rand_dag_sample_f(AA,nv,intv,varm,val,n);
    U(i,j) = data(i,j) - mean(data1(:,j)); 

 end
  data1 = rand_dag_sample_f(AA,nv,ones(1,n),varm,val,n);
  U(i,nv+1) = data(i,nv+1) - mean(data1(:,nv+1));
end




 
 
 varmest = cov(U);
 
 varm;

Ed(num,ind)=(sqrt(sum(sum((varmest - varm).^2))));





for j = 0:1:2^nv-1
display("****************")
j+1
xxxx = decimalToBinaryVector(j,nv)
tmp_ind(j+1,:) = xxxx;
int = find(xxxx==0);
obs = find(xxxx==1);

sy = varmest(nv+1,obs);
sx = varmest(obs,obs);



syt = varm(nv+1,obs);
sxt = varm(obs,obs);


for i =1:1:n
 val = data(i,1:nv);
 V = U(i,obs);  
 datatmp = rand_dag_sample_f(AA,nv,ones(1,n),varm,val,n);
 Eest(i) =  mean(datatmp(:,nv+1))+  sy*inv(sx)*V';
  E(i) = data(i,nv+2);
  Vt = Ut(i,obs);
  E(i) = E(i) + syt*inv(sxt)*Vt';
end

Error(j+1) = sum(abs(Eest-E))./n
end
Error_F(ind,num,:)  = Error;
end


end

% tmpp = (abs(cov(Uapp)-var)./var).*100;
% max(max(tmpp))


save("data_inf_4_1.mat")

clc
clear
% size = 500;
aaa=0;
samples = 300;

 for nv =1000:1:1000
  for j =1:1:10

varm = 3.*eye(nv+1,nv+1)+rand(nv+1,nv+1);

varm = (varm+varm')./2;

 AA = double(triu(rand(nv,nv) <=0.04,1));
dmax =0.04*nv;
S_log = [];
Ad =zeros(nv,nv);
for i =1:50
   S = rand(1,nv);
   S = double((S<=(1-1./dmax)));
   S_log = [S_log ; S];
   S = find(S==1);
    Ad = Ad | Learn_Acnestral_graph_P(S,nv,AA,varm,samples);
    i
%    Ad = double(Ad);
% AA; 
 [nv j i sum(sum((xor(Ad,AA))))]
 Err(1,j,i) = sum(sum((xor(Ad,AA))));
end
%Ad = double(Ad);
%err(j) =  sum(sum((xor(Ad,AA))))
  end
 end
 save("data_1000_shd_On.mat","Err")
clc
 clear

samples = 500;
aaa=0;

 for nv =1000:1:1000
  for j =1:1:10

varm = 3.*eye(nv+1,nv+1)+rand(nv+1,nv+1);

varm = (varm+varm')./2;

 AA = double(triu(rand(nv,nv) <= 1.2*log(nv)/nv,1));
dmax =1.2*log(nv)/nv*nv;
S_log = [];
Ad =zeros(nv,nv);
for i =1:50
   S = rand(1,nv);
   S = double((S<=(1-1./dmax)));
   S_log = [S_log ; S];
   S = find(S==1);
    Ad = Ad | Learn_Acnestral_graph_P(S,nv,AA,varm,samples);
    i
%    Ad = double(Ad);
% AA; 
 [nv j i sum(sum((xor(Ad,AA))))]
 Err(1,j,i) = sum(sum((xor(Ad,AA))));
end
%Ad = double(Ad);
%err(j) =  sum(sum((xor(Ad,AA))))
  end
 end
 save("data_1000_shd_Ologn.mat","Err")


 clc

 clear

 samples = 500;
aaa=0;

 for nv =1000:1:1000
  for j =1:1:10

varm = 3.*eye(nv+1,nv+1)+rand(nv+1,nv+1);

varm = (varm+varm')./2;

 AA = double(triu(rand(nv,nv) <= 4.5/nv,1));
dmax =4.5/nv*nv;
S_log = [];
Ad =zeros(nv,nv);
for i =1:50
   S = rand(1,nv);
   S = double((S<=(1-1./dmax)));
   S_log = [S_log ; S];
   S = find(S==1);
    Ad = Ad | Learn_Acnestral_graph_P(S,nv,AA,varm,samples);
    i
%    Ad = double(Ad);
% AA; 
 [nv j i sum(sum((xor(Ad,AA))))]
 Err(1,j,i) = sum(sum((xor(Ad,AA))));
end
%Ad = double(Ad);
%err(j) =  sum(sum((xor(Ad,AA))))
  end
 end
 save("data_1000_shd_O1.mat","Err")

 clc
clear

aaa=0;
ind =0;
for xxx = 50:50:1000
    ind = ind +1;
 for nv =1000:1:1000
  for j =1:1:50

varm = 2.0.*eye(nv+1,nv+1)+rand(nv+1,nv+1);

varm = (varm+varm')./2;

 AA = double(triu(rand(nv,nv) <= 0.04,1));
dmax = 0.04*nv;
S_log = [];
Ad =zeros(nv,nv);
for i =1:1:xxx
   S = rand(1,nv);
   S = double((S<=(1-1./dmax)));
   S_log = [S_log ; S];
   S = find(S==1);
 
    i;
end

tmp = S_log';
d=0;
 for ii =1:1:nv
   for jj = 1:1:size(tmp,2)
     tmp2 = AA(:,ii).*tmp(:,jj);
     if (sum(tmp2 == AA(:,ii))==nv && tmp(ii,jj) == 0) d(ii) =1;
         ii;
     [ AA(:,ii) tmp(:,jj)];
    break 
     end
 end
end

aaa = (sum(d)==nv);
e(j,ind) = double(aaa);
  end
 end


aaa=0;
e(:,ind);
xxx
end
save("data_infer_1000_On.mat","e")



clc
clear

aaa=0;
ind =0;
for xxx = 50:50:1000
    ind = ind +1;
 for nv =1000:1:1000
  for j =1:1:50

varm = 2.0.*eye(nv+1,nv+1)+rand(nv+1,nv+1);

varm = (varm+varm')./2;

 AA = double(triu(rand(nv,nv) <= 1.2*log(nv)/nv,1));
dmax = 1.2*log(nv)/nv*nv;
S_log = [];
Ad =zeros(nv,nv);
for i =1:1:xxx
   S = rand(1,nv);
   S = double((S<=(1-1./dmax)));
   S_log = [S_log ; S];
   S = find(S==1);
 
    i;
end

tmp = S_log';
d=0;
 for ii =1:1:nv
   for jj = 1:1:size(tmp,2)
     tmp2 = AA(:,ii).*tmp(:,jj);
     if (sum(tmp2 == AA(:,ii))==nv && tmp(ii,jj) == 0) d(ii) =1;
         ii;
     [ AA(:,ii) tmp(:,jj)];
    break 
     end
 end
end

aaa = (sum(d)==nv);
e(j,ind) = double(aaa);
  end
 end


aaa=0;
e(:,ind);
xxx
end
save("data_infer_1000_Ologn.mat","e")



clc
clear

aaa=0;
ind =0;
for xxx = 50:50:1000
    ind = ind +1;
 for nv =1000:1:1000
  for j =1:1:50

varm = 2.0.*eye(nv+1,nv+1)+rand(nv+1,nv+1);

varm = (varm+varm')./2;


 AA = double(triu(rand(nv,nv) <= 4.5/nv,1));
dmax =4.5/nv*nv;
S_log = [];
Ad =zeros(nv,nv);
for i =1:1:xxx
   S = rand(1,nv);
   S = double((S<=(1-1./dmax)));
   S_log = [S_log ; S];
   S = find(S==1);
 
    i;
end

tmp = S_log';
d=0;
 for ii =1:1:nv
   for jj = 1:1:size(tmp,2)
     tmp2 = AA(:,ii).*tmp(:,jj);
     if (sum(tmp2 == AA(:,ii))==nv && tmp(ii,jj) == 0) d(ii) =1;
         ii;
     [ AA(:,ii) tmp(:,jj)];
    break 
     end
 end
end

aaa = (sum(d)==nv);
e(j,ind) = double(aaa);
  end
 end


aaa=0;
e(:,ind);
xxx
end
save("data_infer_1000_O1.mat","e")



