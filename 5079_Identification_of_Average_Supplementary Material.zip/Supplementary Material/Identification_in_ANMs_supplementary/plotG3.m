x =[10:10:100];
% plot(x,err_1,'linewidth',2)
% hold on
% plot(x,err_2,'linewidth',2)
% 
% plot(x,err_3,'linewidth',2)
% grid on
% 
% xlim([5 100])
% xlabel("Number of random interventions")
% ylabel("Probibilty of having sufficient data sets for Inference")
load("data_infer_20_n_d.mat")
options.x_axis = x;
options.marker = "-^"

options.color_line = [179, 63, 64]./255 ;
options.color_area = options.color_line + (1-options.color_line)*2.3/4 ;
plot_areaerrorbar(e,options)
grid on
xlabel("Sample Size")
ylabel("Percentage Absolute Error")
load("data_infer_20_lgn_d.mat")
options.x_axis = x;
options.marker = "-o"
options.color_line = [72, 161, 77]./255 ;
options.color_area = options.color_line + (1-options.color_line)*2.3/4 ;
plot_areaerrorbar(e,options)
grid on
xlabel("Sample Size")
ylabel("Percentage Absolute Error")

load("data_infer_20_cnt_d.mat")
options.x_axis = x;
options.marker = "-square"
options.color_line = [01, 119, 179]./255 ;
options.color_area = options.color_line + (1-options.color_line)*2.3/4 ;
plot_areaerrorbar(e,options)

grid on
xlabel("Sample Size")
ylabel("Percentage Absolute Error")
ylim([0 1])

box on
legend("","$d_{max}$ = $\mathcal{O}$(n)","","$d_{max}$ = $\mathcal{O}$(log(n))","","$d_{max}$ = $\mathcal{O}$(1)","Interpreter","latex")