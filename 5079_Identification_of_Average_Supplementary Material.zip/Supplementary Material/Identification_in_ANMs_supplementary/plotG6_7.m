% load("data_1000_shd_On.mat");
% 
% E = squeeze(Err(1,:,:));
% options.marker = "-^"
% 
% options.color_line = [179, 63, 64]./255 ;
% options.color_area = options.color_line + (1-options.color_line)*2.3/4 ;
% options.x_axis = [1:1:size(E,2)].*2*log(1000);
% plot_areaerrorbar(E,options)
% xlabel("Number of Random Interventions")
% ylabel("Structural Hamming Distance (SHD)")
% grid on
% set(gca, 'YScale', 'log')
% 
% 
% load("data_1000_shd_Ologn.mat");
% 
% E = squeeze(Err(1,:,:))
% options.marker = "-o"
% options.color_line = [72, 161, 77]./255 ;
% options.color_area = options.color_line + (1-options.color_line)*2.3/4 ;
% 
% options.x_axis = [1:1:size(E,2)].*2*log(1000);
% plot_areaerrorbar(E,options)
% xlabel("Number of Random Interventions")
% ylabel("Structural Hamming Distance (SHD)")
% grid on
% set(gca, 'YScale', 'log')
% 
% 
% load("data_1000_shd_O1.mat");
% 
% E = squeeze(Err(1,:,:));
% options.marker = "-square"
% options.color_line = [01, 119, 179]./255 ;
% options.color_area = options.color_line + (1-options.color_line)*2.3/4 ;
% options.x_axis = [1:1:size(E,2)].*2*log(1000);
% plot_areaerrorbar(E,options)
% xlabel("Number of Random Interventions")
% ylabel("Structural Hamming Distance (SHD)")
% grid on
% 
% xlim([2*log(1000) 50*2*log(1000)])
% set(gca, 'YScale', 'log')
% legend("","$d_{max}$ = $\mathcal{O}$(n)","","$d_{max}$ = $\mathcal{O}$(log(n))","","$d_{max}$ = $\mathcal{O}$(1)","Interpreter","latex")
% 
% figure
% load("data_infer_1000_On.mat");
% options.marker = "-^"
% 
% options.color_line = [179, 63, 64]./255 ;
% options.color_area = options.color_line + (1-options.color_line)*2.3/4 ;
% options.x_axis = 50:50:1000;
% plot_areaerrorbar(e,options)
% xlabel("Number of Random Interventions")
% ylabel("Proportions of DAGs with suffiecient data sets for inference")
% xlim([0 1000])
% ylim([0 1])
% grid on
% 
% load("data_infer_1000_Ologn.mat");
% options.marker = "-o"
% options.color_line = [72, 161, 77]./255 ;
% options.color_area = options.color_line + (1-options.color_line)*2.3/4 ;
% 
% options.x_axis = 50:50:1000;
% plot_areaerrorbar(e,options)
% xlabel("Number of Random Interventions")
% ylabel("Proportions of DAGs with suffiecient data sets for inference")
% xlim([0 1000])
% ylim([0 1])
% grid on


% 
% load("data_infer_1000_O1.mat");
% options.marker = "-square"
% options.color_line = [01, 119, 179]./255 ;
% options.color_area = options.color_line + (1-options.color_line)*2.3/4 ;
% options.x_axis = 50:50:1000;
% plot_areaerrorbar(e,options)
% 
% xlabel("Number of Random Interventions")
% ylabel("Proportions of DAGs with suffiecient data sets for inference")
% xlim([0 1000])
% ylim([0 1])
% grid on
% legend("","$d_{max}$ = $\mathcal{O}$(n)","","$d_{max}$ = $\mathcal{O}$(log(n))","","$d_{max}$ = $\mathcal{O}$(1)","Interpreter","latex")