function [data] = rand_dag_sample(A,n,intv,varm,smp)
size = smp;
X = zeros(size,n);

mu = zeros(1,n+1);


U = mvnrnd(mu,varm,size);

for i =1:1:n
   X(:,i) = (1-intv(i))*((X+sin(X)+cos(X))*A(:,i)+U(:,i)) +intv(i)*rand(size,1);
end


Y = X*ones(n,1)+U(:,n+1);

data =[X Y U];
end