function [data,U] = rand_dag_sample_f(A,nv,intv,varm,val,n)

size = n;
n=nv;
X = zeros(size,n);

mu = zeros(1,n+1);


U = mvnrnd(mu,varm,size);

X(:,1) = sample_dist([0.7295 0.231 0.0395],size);
X(:,2) = sample_dist_D([0.315 0.035 0.3375 0.05 0.12 0.1425],size);
X(:,3) = (X(:,1) == 0).*normrnd(0,30) + (X(:,1) == 1).*normrnd(0,50) + (X(:,1) == 2).*normrnd(0,30) + 100*X(:,2);
X(:,4) = sample_dist([0.35 0.45 0.20],size);
X(:,4) = (X(:,4) == 0).*normrnd(60,10) + (X(:,4) == 1).*normrnd(180,20) + (X(:,4) == 2).*normrnd(360,40);

for i =1:1:n
   X(:,i) = (1-intv(i))*(X(:,i)) +intv(i)*val(i);
end

 
Y = 1.02*X(:,3)+1.04*X(:,4)+U(:,n+1);

data =[X Y Y-U(:,n+1)];

end