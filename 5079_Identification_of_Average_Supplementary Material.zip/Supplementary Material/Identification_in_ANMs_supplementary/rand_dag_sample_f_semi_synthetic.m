function [data,U] = rand_dag_sample_f_semi_synthetic(A,nv,intv,varm,val,n,Data,w)
size = n;
n=nv;
X = zeros(size,n);

mu = zeros(1,n+1);


U = mvnrnd(mu,varm,size);
index = ceil(rand(1,size)*1000); 
for i =1:1:n
     X(:,i) = (1-intv(i))*(Data(index,i)+U(:,i)) +intv(i)*val(i);
end


Y = X*w+U(:,n+1);

data =[X Y Y-U(:,n+1)];

end