clc
clear
close all
warning off 
% data is already stored in the folder
% if you want to run experiments and generate fresh data for plots uncomment

%evalc("data_generator"); % uncomment for new data for plots from sythetic experiments. It take some time
%to run

%evalc("semi_synthetic_experiment") % uncomment to run the semi-syntheic experiment and genrate new data for plots
% It take some time to run

figure
evalc("plotG5");
figure
evalc("plotG8_9");
% semi-synthetic experiment results
figure
evalc("plotG10");