function [out] = sample_dist(P,n)
p1 = cumsum(P);
p1 = repmat(p1,n,1);
r = rand(n,1);
tmp = r>p1;
out = sum(tmp,2);
end